<?php
header('Content-Type: application/json');

// Eksekusi skrip shell untuk cek status layanan
$output = shell_exec('/usr/local/bin/check.sh');

// Menampilkan hasil sebagai JSON
echo $output;
?>
